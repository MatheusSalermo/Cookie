<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" href="css/album.css">
  <link href="../assets/dist/css/bootstrap.css" rel="stylesheet">

    <title>Projeto Cookie</title>
  </head>
  <body>
  

<background image= 'img/campo.jpg'>


  <form method="post" action="cookie.php">
            Categoria:
            <select name='slcCategoria'>
                <option value="1">Camisas de Time</option>
                <option value="2">Chuteiras</option>
                <option value="3">Bolas de futebol</option>
                <option value="4">Calções</option>
            </select>
            <input type="submit" value="Pesquisar">
        </form>

        <h1>Lista de Produtos</h1>
        <?php
            if(isset($_COOKIE['codcategoria'])){
                //se o cookie existir, o usuário informou seu categoria de preferência
                // então vamos carregar os produtos desta categoria em cima das demais
                if($_COOKIE['codcategoria'] == 1){ //categoria escolhida ROUPAS
                    echo("
                    <main role='main'>

                    <section class='jumbotron text-center'>
                      <div class='container'>
                    
                      </div>
                    </section>
                  
                    <div class='album py-5 bg-light''>
                      <div class='container'>
                  
                        <div class='row'>
                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/cAMISAcORINTHIANS.jpg'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Camisa I - Corinthians</h5></center>
                               <p>- Camisa Temporada 2018/2019</p>
                               <p>- Cor Principal: Branca </p>
                               <p>- Tamanhos disponíveis: P, M e G</p>
                                <center><h5 class='card-title'>R$ 200,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>

                          

                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/CAMISApsg.jpg'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Camisa III - Paris Saint Germain</h5></center>
                              <p>- Camisa Temporada 2019/2020</p>
                              <p>- Cor Principal: Preta </p>
                              <p>- Tamanhos disponíveis: P e G</p>
                                <center><h5 class='card-title'>R$ 300,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>



                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/camisaSelecao.jpg'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Camisa I - Seleção Brasileira </h5></center>
                              <p>- Camisa Especial Copa América</p>
                              <p>- Cor Principal: Amarela </p>
                              <p>- Tamanhos disponíveis: P, M e G</p>
                                <center><h5 class='card-title'>R$ 250,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>



                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/hypervenomVerde.jpg'>
                              <div class='card-body'>
                              <center> <h5 class='card-title'>Nike Hypervenom</h5></center>
                              <p>- Chuteira Ano de 2017</p>
                              <p>- Cor Principal: Verde </p>
                              <p>- Tamanhos disponíveis: 37 ao 43</p>
                                <center><h5 class='card-title'>R$ 150,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/phantomVerde.png'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Nike Phantom Infantil </h5></center>
                              <p>- Chuteira Ano de 2020</p>
                              <p>- Cor Principal: Verde </p>
                              <p>- Tamanhos disponíveis: 28 ao 34</p>
                                <center><h5 class='card-title'>R$ 200,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>



                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/mercurialAzul.png'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Nike Mercurial</h5></center>
                              <p>- Chuteira Ano de 2019</p>
                              <p>- Cor Principal: Azul </p>
                              <p>- Tamanhos disponíveis: 35 ao 41</p>
                                <center><h5 class='card-title'>R$ 500,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>



                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/bolaBrasileirao.jpg'>
                              <div class='card-body'>
                              <center> <h5 class='card-title'>Bola Oficial - Brasileirão</h5></center>
                              <p>- Bola Brasileirão 2019</p>
                              <p>- Cor Principal: Branca </p>
                              <p>- Tamanho: Oficial (5)</p>
                                <center><h5 class='card-title'>R$ 800,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/bolaBarcelona.png'>
                              <div class='card-body'>
                              <center> <h5 class='card-title'>Mini Bola - Barcelona</h5></center>
                              <p>- Mini bola Barcelona</p>
                              <p>- Cor Principal: Azul e Grená </p>
                              <p>- Tamanho: Mini (2)</p>
                                <center><h5 class='card-title'>R$ 50,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/bolaPSG.png'>
                              <div class='card-body'>
                              <center> <h5 class='card-title'>Bola Torcedor - PSG</h5></center>
                              <p>- Bola Torcedor (Réplica)</p>
                              <p>- Cor Principal: Azul </p>
                              <p>- Tamanho: Oficial (5)</p>
                                <center><h5 class='card-title'>R$ 150,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/calcaoCorinthians.jpg'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Calção Corinthians</h5></center>
                              <p>- Calção Corinthians - 2018</p>
                              <p>- Cor Principal: Preta </p>
                              <p>- Tamanhos disponíveis: M e G</p>
                                <center><h5 class='card-title'>R$ 100,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/calcaoPSG.jpg'>
                              <div class='card-body'>
                              <center><h5 class='card-title'>Calção Paris Saint Germain</h5></center>
                              <p>- Calção PSG 2019/2020</p>
                              <p>- Cor Principal: Vermelho Fluorescente </p>
                              <p>- Tamanhos disponíveis: P </p>
                                <center><h5 class='card-title'>R$ 200,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>


                          <div class='col-md-4'>
                            <div class='card mb-4 shadow-sm'>
                              <img src='img/cALCAOsELECAO.jpg'>
                              <div class='card-body'>
                              <center> <h5 class='card-title'>Calção Seleção Brasileira</h5></center>
                              <p>- Calção Seleção Brasileira 2020</p>
                              <p>- Cor Principal: Azul </p>
                              <p>- Tamanhos disponíveis: P, M, G e GG</p>
                                <center><h5 class='card-title'>R$ 130,00</h5></center>
                                  <center><a href='#' class='btn btn-primary'>Comprar</a></center>
                
                              </div>
                            </div>
                          </div>

    
                    ");
                }
                else if($_COOKIE['codcategoria'] == 2){ 
                    echo("
                    <main role='main'>

                    <section class='jumbotron text-center'>
                      <div class='container'>
                    
                      </div>
                    </section>
                  
                    <div class='album py-5 bg-light''>
                      <div class='container'>
                  
                        <div class='row'>

                    <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/hypervenomVerde.jpg'>
                      <div class='card-body'>
                      <center> <h5 class='card-title'>Nike Hypervenom</h5></center>
                      <p>- Chuteira Ano de 2017</p>
                      <p>- Cor Principal: Verde </p>
                      <p>- Tamanhos disponíveis: 37 ao 43</p>
                        <center><h5 class='card-title'>R$ 150,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>


                  <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/phantomVerde.png'>
                      <div class='card-body'>
                      <center><h5 class='card-title'>Nike Phantom Infantil </h5></center>
                      <p>- Chuteira Ano de 2020</p>
                      <p>- Cor Principal: Verde </p>
                      <p>- Tamanhos disponíveis: 28 ao 34</p>
                        <center><h5 class='card-title'>R$ 200,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>



                  <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/mercurialAzul.png'>
                      <div class='card-body'>
                      <center><h5 class='card-title'>Nike Mercurial</h5></center>
                      <p>- Chuteira Ano de 2019</p>
                      <p>- Cor Principal: Azul </p>
                      <p>- Tamanhos disponíveis: 35 ao 41</p>
                        <center><h5 class='card-title'>R$ 500,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>

                  <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaBrasileirao.jpg'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Bola Oficial - Brasileirão</h5></center>
                    <p>- Bola Brasileirão 2019</p>
                    <p>- Cor Principal: Branca </p>
                    <p>- Tamanho: Oficial (5)</p>
                      <center><h5 class='card-title'>R$ 800,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaBarcelona.png'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Mini Bola - Barcelona</h5></center>
                    <p>- Mini bola Barcelona</p>
                    <p>- Cor Principal: Azul e Grená </p>
                    <p>- Tamanho: Mini (2)</p>
                      <center><h5 class='card-title'>R$ 50,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaPSG.png'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Bola Torcedor - PSG</h5></center>
                    <p>- Bola Torcedor (Réplica)</p>
                    <p>- Cor Principal: Azul </p>
                    <p>- Tamanho: Oficial (5)</p>
                      <center><h5 class='card-title'>R$ 150,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/calcaoCorinthians.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Calção Corinthians</h5></center>
                    <p>- Calção Corinthians - 2018</p>
                    <p>- Cor Principal: Preta </p>
                    <p>- Tamanhos disponíveis: M e G</p>
                      <center><h5 class='card-title'>R$ 100,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/calcaoPSG.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Calção Paris Saint Germain</h5></center>
                    <p>- Calção PSG 2019/2020</p>
                    <p>- Cor Principal: Vermelho Fluorescente </p>
                    <p>- Tamanhos disponíveis: P </p>
                      <center><h5 class='card-title'>R$ 200,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/cALCAOsELECAO.jpg'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Calção Seleção Brasileira</h5></center>
                    <p>- Calção Seleção Brasileira 2020</p>
                    <p>- Cor Principal: Azul </p>
                    <p>- Tamanhos disponíveis: P, M, G e GG</p>
                      <center><h5 class='card-title'>R$ 130,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>

                <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/cAMISAcORINTHIANS.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa I - Corinthians</h5></center>
                   <p>- Camisa Temporada 2018/2019</p>
                   <p>- Cor Principal: Branca </p>
                   <p>- Tamanhos disponíveis: P, M e G</p>
                    <center><h5 class='card-title'>R$ 200,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>

              

              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/CAMISApsg.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa III - Paris Saint Germain</h5></center>
                  <p>- Camisa Temporada 2019/2020</p>
                  <p>- Cor Principal: Preta </p>
                  <p>- Tamanhos disponíveis: P e G</p>
                    <center><h5 class='card-title'>R$ 300,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>



              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/camisaSelecao.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa I - Seleção Brasileira </h5></center>
                  <p>- Camisa Especial Copa América</p>
                  <p>- Cor Principal: Amarela </p>
                  <p>- Tamanhos disponíveis: P, M e G</p>
                    <center><h5 class='card-title'>R$ 250,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>


                    ");
                }


                else if($_COOKIE['codcategoria'] == 3){ 
                  echo("
                  <main role='main'>

                  <section class='jumbotron text-center'>
                    <div class='container'>
                  
                    </div>
                  </section>
                
                  <div class='album py-5 bg-light''>
                    <div class='container'>
                
                      <div class='row'>

                  <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaBrasileirao.jpg'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Bola Oficial - Brasileirão</h5></center>
                    <p>- Bola Brasileirão 2019</p>
                    <p>- Cor Principal: Branca </p>
                    <p>- Tamanho: Oficial (5)</p>
                      <center><h5 class='card-title'>R$ 800,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaBarcelona.png'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Mini Bola - Barcelona</h5></center>
                    <p>- Mini bola Barcelona</p>
                    <p>- Cor Principal: Azul e Grená </p>
                    <p>- Tamanho: Mini (2)</p>
                      <center><h5 class='card-title'>R$ 50,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/bolaPSG.png'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Bola Torcedor - PSG</h5></center>
                    <p>- Bola Torcedor (Réplica)</p>
                    <p>- Cor Principal: Azul </p>
                    <p>- Tamanho: Oficial (5)</p>
                      <center><h5 class='card-title'>R$ 150,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>

                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/calcaoCorinthians.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Calção Corinthians</h5></center>
                    <p>- Calção Corinthians - 2018</p>
                    <p>- Cor Principal: Preta </p>
                    <p>- Tamanhos disponíveis: M e G</p>
                      <center><h5 class='card-title'>R$ 100,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/calcaoPSG.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Calção Paris Saint Germain</h5></center>
                    <p>- Calção PSG 2019/2020</p>
                    <p>- Cor Principal: Vermelho Fluorescente </p>
                    <p>- Tamanhos disponíveis: P </p>
                      <center><h5 class='card-title'>R$ 200,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>


                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/cALCAOsELECAO.jpg'>
                    <div class='card-body'>
                    <center> <h5 class='card-title'>Calção Seleção Brasileira</h5></center>
                    <p>- Calção Seleção Brasileira 2020</p>
                    <p>- Cor Principal: Azul </p>
                    <p>- Tamanhos disponíveis: P, M, G e GG</p>
                      <center><h5 class='card-title'>R$ 130,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>

                <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/cAMISAcORINTHIANS.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa I - Corinthians</h5></center>
                   <p>- Camisa Temporada 2018/2019</p>
                   <p>- Cor Principal: Branca </p>
                   <p>- Tamanhos disponíveis: P, M e G</p>
                    <center><h5 class='card-title'>R$ 200,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>

              

              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/CAMISApsg.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa III - Paris Saint Germain</h5></center>
                  <p>- Camisa Temporada 2019/2020</p>
                  <p>- Cor Principal: Preta </p>
                  <p>- Tamanhos disponíveis: P e G</p>
                    <center><h5 class='card-title'>R$ 300,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>



              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/camisaSelecao.jpg'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Camisa I - Seleção Brasileira </h5></center>
                  <p>- Camisa Especial Copa América</p>
                  <p>- Cor Principal: Amarela </p>
                  <p>- Tamanhos disponíveis: P, M e G</p>
                    <center><h5 class='card-title'>R$ 250,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>

              <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/hypervenomVerde.jpg'>
                <div class='card-body'>
                <center> <h5 class='card-title'>Nike Hypervenom</h5></center>
                <p>- Chuteira Ano de 2017</p>
                <p>- Cor Principal: Verde </p>
                <p>- Tamanhos disponíveis: 37 ao 43</p>
                  <center><h5 class='card-title'>R$ 150,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>


            <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/phantomVerde.png'>
                <div class='card-body'>
                <center><h5 class='card-title'>Nike Phantom Infantil </h5></center>
                <p>- Chuteira Ano de 2020</p>
                <p>- Cor Principal: Verde </p>
                <p>- Tamanhos disponíveis: 28 ao 34</p>
                  <center><h5 class='card-title'>R$ 200,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>



            <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/mercurialAzul.png'>
                <div class='card-body'>
                <center><h5 class='card-title'>Nike Mercurial</h5></center>
                <p>- Chuteira Ano de 2019</p>
                <p>- Cor Principal: Azul </p>
                <p>- Tamanhos disponíveis: 35 ao 41</p>
                  <center><h5 class='card-title'>R$ 500,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>

                  ");
              }


              else if($_COOKIE['codcategoria'] == 4){ 
                echo("
                <main role='main'>

                <section class='jumbotron text-center'>
                  <div class='container'>
                
                  </div>
                </section>
              
                <div class='album py-5 bg-light''>
                  <div class='container'>
              
                    <div class='row'>
                    <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/calcaoCorinthians.jpg'>
                      <div class='card-body'>
                      <center><h5 class='card-title'>Calção Corinthians</h5></center>
                      <p>- Calção Corinthians - 2018</p>
                      <p>- Cor Principal: Preta </p>
                      <p>- Tamanhos disponíveis: M e G</p>
                        <center><h5 class='card-title'>R$ 100,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>
  
  
                  <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/calcaoPSG.jpg'>
                      <div class='card-body'>
                      <center><h5 class='card-title'>Calção Paris Saint Germain</h5></center>
                      <p>- Calção PSG 2019/2020</p>
                      <p>- Cor Principal: Vermelho Fluorescente </p>
                      <p>- Tamanhos disponíveis: P </p>
                        <center><h5 class='card-title'>R$ 200,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>
  
  
                  <div class='col-md-4'>
                    <div class='card mb-4 shadow-sm'>
                      <img src='img/cALCAOsELECAO.jpg'>
                      <div class='card-body'>
                      <center> <h5 class='card-title'>Calção Seleção Brasileira</h5></center>
                      <p>- Calção Seleção Brasileira 2020</p>
                      <p>- Cor Principal: Azul </p>
                      <p>- Tamanhos disponíveis: P, M, G e GG</p>
                        <center><h5 class='card-title'>R$ 130,00</h5></center>
                          <center><a href='#' class='btn btn-primary'>Comprar</a></center>
        
                      </div>
                    </div>
                  </div>
  
                  <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/cAMISAcORINTHIANS.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Camisa I - Corinthians</h5></center>
                     <p>- Camisa Temporada 2018/2019</p>
                     <p>- Cor Principal: Branca </p>
                     <p>- Tamanhos disponíveis: P, M e G</p>
                      <center><h5 class='card-title'>R$ 200,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>
  
                
  
                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/CAMISApsg.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Camisa III - Paris Saint Germain</h5></center>
                    <p>- Camisa Temporada 2019/2020</p>
                    <p>- Cor Principal: Preta </p>
                    <p>- Tamanhos disponíveis: P e G</p>
                      <center><h5 class='card-title'>R$ 300,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>
  
  
  
                <div class='col-md-4'>
                  <div class='card mb-4 shadow-sm'>
                    <img src='img/camisaSelecao.jpg'>
                    <div class='card-body'>
                    <center><h5 class='card-title'>Camisa I - Seleção Brasileira </h5></center>
                    <p>- Camisa Especial Copa América</p>
                    <p>- Cor Principal: Amarela </p>
                    <p>- Tamanhos disponíveis: P, M e G</p>
                      <center><h5 class='card-title'>R$ 250,00</h5></center>
                        <center><a href='#' class='btn btn-primary'>Comprar</a></center>
      
                    </div>
                  </div>
                </div>
  
  
                <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/hypervenomVerde.jpg'>
                  <div class='card-body'>
                  <center> <h5 class='card-title'>Nike Hypervenom</h5></center>
                  <p>- Chuteira Ano de 2017</p>
                  <p>- Cor Principal: Verde </p>
                  <p>- Tamanhos disponíveis: 37 ao 43</p>
                    <center><h5 class='card-title'>R$ 150,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>
  
  
              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/phantomVerde.png'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Nike Phantom Infantil </h5></center>
                  <p>- Chuteira Ano de 2020</p>
                  <p>- Cor Principal: Verde </p>
                  <p>- Tamanhos disponíveis: 28 ao 34</p>
                    <center><h5 class='card-title'>R$ 200,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>
  
  
  
              <div class='col-md-4'>
                <div class='card mb-4 shadow-sm'>
                  <img src='img/mercurialAzul.png'>
                  <div class='card-body'>
                  <center><h5 class='card-title'>Nike Mercurial</h5></center>
                  <p>- Chuteira Ano de 2019</p>
                  <p>- Cor Principal: Azul </p>
                  <p>- Tamanhos disponíveis: 35 ao 41</p>
                    <center><h5 class='card-title'>R$ 500,00</h5></center>
                      <center><a href='#' class='btn btn-primary'>Comprar</a></center>
    
                  </div>
                </div>
              </div>


              <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/bolaBrasileirao.jpg'>
                <div class='card-body'>
                <center> <h5 class='card-title'>Bola Oficial - Brasileirão</h5></center>
                <p>- Bola Brasileirão 2019</p>
                <p>- Cor Principal: Branca </p>
                <p>- Tamanho: Oficial (5)</p>
                  <center><h5 class='card-title'>R$ 800,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>


            <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/bolaBarcelona.png'>
                <div class='card-body'>
                <center> <h5 class='card-title'>Mini Bola - Barcelona</h5></center>
                <p>- Mini bola Barcelona</p>
                <p>- Cor Principal: Azul e Grená </p>
                <p>- Tamanho: Mini (2)</p>
                  <center><h5 class='card-title'>R$ 50,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>


            <div class='col-md-4'>
              <div class='card mb-4 shadow-sm'>
                <img src='img/bolaPSG.png'>
                <div class='card-body'>
                <center> <h5 class='card-title'>Bola Torcedor - PSG</h5></center>
                <p>- Bola Torcedor (Réplica)</p>
                <p>- Cor Principal: Azul </p>
                <p>- Tamanho: Oficial (5)</p>
                  <center><h5 class='card-title'>R$ 150,00</h5></center>
                    <center><a href='#' class='btn btn-primary'>Comprar</a></center>
  
                </div>
              </div>
            </div>
                ");
            }
            }
            else{
                //se o cookie não existir, o usuário não informou suas preferências na cateogria
                echo("
             



                    ");
            }
        ?>








    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>